# FinAI - Assistente Financeiro Inteligente

Projeto desenvolvido para o desafio da DIO.

## Funcionalidades
- Responde dúvidas financeiras básicas
- Utiliza base de conhecimento em JSON
- Não inventa respostas
- Informa quando não possui informação suficiente

## Execução

```bash
python src/app.py
```

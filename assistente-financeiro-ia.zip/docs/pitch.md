# Pitch

Problema: dificuldade em organizar finanças.
Solução: assistente virtual financeiro simples.

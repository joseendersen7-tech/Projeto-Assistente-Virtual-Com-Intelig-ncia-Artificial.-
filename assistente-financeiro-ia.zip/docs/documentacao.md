# Documentação

Assistente financeiro para orientação básica sobre orçamento, dívidas e economia.

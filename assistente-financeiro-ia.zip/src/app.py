import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
ARQ = os.path.join(BASE_DIR, "data", "conhecimento.json")

with open(ARQ, "r", encoding="utf-8") as f:
    conhecimento = json.load(f)

print("FINAI - Assistente Financeiro Inteligente")
print("Digite 'sair' para encerrar.")

while True:
    pergunta = input("Você: ").lower()

    if pergunta == "sair":
        print("FinAI: Até logo!")
        break

    respondeu = False

    for chave, resposta in conhecimento.items():
        if chave in pergunta:
            print("FinAI:", resposta)
            respondeu = True
            break

    if not respondeu:
        print("FinAI: Não possuo informação suficiente para responder.")
